<?php
require_once 'conn.php';
$slug = 'soups';
$category = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM categories WHERE slug = '$slug' LIMIT 1"));
$catId = $category['id'] ?? 0;
$foods = mysqli_query($conn, "SELECT * FROM foods WHERE category_id = $catId AND status = 'active' ORDER BY id");
?>
<!DOCTYPE html>
<html>
<head>
<title>Healthy Soups - Wellness Bite</title>

<style>
body{
    font-family: Arial, sans-serif;
    background:#f5f5f5;
    margin:0;
    padding:20px;
}

h1{
    text-align:center;
    color:#2c3e50;
    margin-bottom:30px;
}

.food-container{
    display:flex;
    justify-content:center;
    flex-wrap:wrap;
    gap:25px;
}

.food-card{
    width:250px;
    background:white;
    border-radius:15px;
    overflow:hidden;
    text-align:center;
    box-shadow:0 4px 10px rgba(0,0,0,0.15);
    transition:0.4s;
}

.food-card:hover{
    transform:translateY(-10px);
}

.food-card img{
    width:100%;
    height:180px;
    object-fit:cover;
}

.food-card h3{
    margin:15px 0 10px;
    color:#333;
}

.price{
    font-size:20px;
    color:green;
    font-weight:bold;
}

.btn{
    display:inline-block;
    background:orange;
    color:white;
    padding:10px 18px;
    text-decoration:none;
    border-radius:5px;
    margin-bottom:20px;
}

.btn:hover{
    background:#ff6600;
}

.back{
    text-align:center;
    margin-top:30px;
}

.empty{
    text-align:center;
    color:#999;
    margin-top:40px;
}
</style>

</head>
<body>

<h1>🍲 Healthy Soups</h1>

<div class="food-container">

<?php if (mysqli_num_rows($foods) === 0): ?>
    <p class="empty">No items available in this category right now. Please check back soon!</p>
<?php endif; ?>

<?php while ($f = mysqli_fetch_assoc($foods)):
    $img = $f['image'] ? htmlspecialchars($f['image']) : 'veg.jpg';
?>
    <div class="food-card">
        <img src="<?php echo $img; ?>" alt="<?php echo htmlspecialchars($f['name']); ?>" onerror="this.src='veg.jpg'">
        <h3><?php echo htmlspecialchars($f['name']); ?></h3>
        <p class="price">₹<?php echo number_format($f['price'], 2); ?></p>
        <a href="payment.php?food_id=<?php echo $f['id']; ?>&item=<?php echo urlencode($f['name']); ?>&price=<?php echo $f['price']; ?>" class="btn">Order Now</a>
    </div>
<?php endwhile; ?>

</div>

<div class="back">
    <a href="index.php" class="btn">← Back to Home</a>
</div>

</body>
</html>
