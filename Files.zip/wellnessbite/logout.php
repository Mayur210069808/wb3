
<?php
session_start();

// Clear all user session variables
$_SESSION = array();

// Remove the session cookie, if enabled
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destroy the current session
session_destroy();

// Redirect to the user login page
header("Location: login.php");
exit();
?>
