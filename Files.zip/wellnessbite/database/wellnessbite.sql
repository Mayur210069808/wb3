-- ============================================================
--  Wellness Bite - Database Schema
--  Import this file in phpMyAdmin (XAMPP) to create everything
--  needed for the website + admin panel in one go.
-- ============================================================

CREATE DATABASE IF NOT EXISTS wellnessbite CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE wellnessbite;

-- ------------------------------------------------------------
-- Admin accounts (for the Admin Panel)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin login -> username: admin | password: admin123
-- (password is stored bcrypt-hashed, never in plain text)
INSERT INTO admin (username, password) VALUES
('admin', '$2y$10$LFfmWj29cluZPWZyj91e7uU4KNc3UX/SUNx/Yux50tnC3tMrM3eDu');

-- ------------------------------------------------------------
-- Food categories (Salad, Fruits, Smoothies, Diet Meals, Soups...)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(20) DEFAULT '🍽️',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO categories (name, slug, icon) VALUES
('Salad', 'salad', '🥗'),
('Fruits', 'fruits', '🍎'),
('Smoothies', 'smoothies', '🥤'),
('Diet Meals', 'diet', '🥑'),
('Soups', 'soups', '🍲');

-- ------------------------------------------------------------
-- Food items
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS foods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(255) DEFAULT '',
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT '',
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO foods (category_id, name, description, price, image, status) VALUES
(1, 'Green Salad', 'Fresh mixed green vegetable salad', 120, 'salad2.jpg', 'active'),
(1, 'Greek Salad', 'Classic Greek salad with feta and olives', 150, 'greek.jpg', 'active'),
(1, 'Fruit Salad', 'Seasonal fruit medley salad', 130, 'fruitsalad.jpg', 'active'),
(2, 'Mango', 'Fresh ripe mangoes', 90, 'mango1.jpg', 'active'),
(2, 'Banana', 'Fresh bananas, rich in potassium', 60, 'banana.jpg', 'active'),
(2, 'Orange', 'Juicy fresh oranges', 80, 'orange.jpg', 'active'),
(2, 'Papaya', 'Fresh cut papaya', 70, 'papaya.jpg', 'active'),
(3, 'Mango Smoothie', 'Creamy mango smoothie', 120, 'smoothie1.jpg', 'active'),
(3, 'Banana Smoothie', 'Banana smoothie with honey', 110, 'smoothie2.jpg', 'active'),
(3, 'Berry Smoothie', 'Mixed berry smoothie', 140, 'smoothie3.jpg', 'active'),
(4, 'Oats Meal', 'Nutritious oats breakfast bowl', 120, 'meal1.jpg', 'active'),
(4, 'Sprouts Bowl', 'High protein sprouts diet bowl', 110, 'sprouts.jpg', 'active'),
(4, 'Veggie Bowl', 'Steamed mixed vegetable bowl', 130, 'veg.jpg', 'active'),
(5, 'Tomato Soup', 'Classic tomato soup', 90, 'soup1.jpg', 'active'),
(5, 'Sweet Corn Soup', 'Sweet corn soup', 100, 'soup2.jpg', 'active'),
(5, 'Mixed Veg Soup', 'Healthy mixed vegetable soup', 100, 'soup3.jpg', 'active');

-- ------------------------------------------------------------
-- Customers (registered site users)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mobile VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    status ENUM('active','blocked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Orders
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NULL,
    customer_name VARCHAR(150) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    address VARCHAR(255) NOT NULL,
    food_id INT NULL,
    food_name VARCHAR(150) NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_method VARCHAR(50) NOT NULL,
    status ENUM('Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (food_id) REFERENCES foods(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Payments (linked 1-1 with orders)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    method VARCHAR(50) NOT NULL,
    status ENUM('Pending','Paid','Failed','Refunded') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Offers / promo codes
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_percent INT NOT NULL DEFAULT 0,
    description VARCHAR(255) DEFAULT '',
    valid_from DATE NULL,
    valid_to DATE NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO offers (title, code, discount_percent, description, valid_from, valid_to, status) VALUES
('Welcome Offer', 'WELCOME10', 10, 'Get 10% off on your first order', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 60 DAY), 'active'),
('Weekend Special', 'WEEKEND20', 20, '20% off every weekend', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 90 DAY), 'active');
