# Wellness Bite - Setup Guide (XAMPP)

## 1. Copy the files
Copy this whole folder into your XAMPP htdocs directory, e.g.:

    C:\xampp\htdocs\wellness-bite\

## 2. Import the database
1. Start Apache and MySQL from the XAMPP Control Panel.
2. Open phpMyAdmin: http://localhost/phpmyadmin
3. Click "Import" -> choose the file: database/wellnessbite.sql
4. Click "Go". This creates the `wellnessbite` database with all
   tables (admin, categories, foods, customers, orders, payments,
   offers) and loads in your existing categories/food items as
   sample data.

## 3. Visit the site
    Public site:  http://localhost/wellness-bite/index.php
    Admin panel:  http://localhost/wellness-bite/admin_login.php

## 4. Default admin login
    Username: admin
    Password: admin123

(Change this after logging in by updating the `admin` table in
phpMyAdmin, or add a "change password" feature later if you want.)

## What's included

- **admin/** - the full admin panel (Dashboard, Manage Categories,
  Add/Update/Delete Food, Manage Orders, Update Order Status,
  Manage Customers, Manage Payments, View Reports, Manage Offers,
  Logout). Protected by session login - you can't reach any admin
  page without logging in first.

- **database/wellnessbite.sql** - the full schema + sample data.
  Re-import any time you want to reset to a clean state.

- **conn.php** - shared DB connection (localhost / root / no
  password / database "wellnessbite"), used by both the public
  site and the admin panel.

- **uploads/** - where food images uploaded through the admin panel
  are stored.

- The public category pages (salad.php, fruits.php, smoothies.php,
  diet.php, soups.php) and the homepage's "Popular Foods" section
  now pull live data from the database, so anything you add, edit,
  or delete in the admin panel shows up on the site automatically.

- register.php / login.php now create and authenticate real
  customer accounts (passwords are hashed, never stored in plain
  text). payment.php now saves a real order + payment record to
  the database when a customer checks out, and order.php shows the
  actual saved order back to them.

## Notes
- All admin panel database queries use prepared statements to
  protect against SQL injection.
- If you add new food images through the admin panel, they're
  saved into /uploads and referenced automatically - no manual
  file copying needed.
