<?php
session_start();
require_once __DIR__ . '/conn.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {

        $error = 'Please enter email and password.';

    } else {

        $sql = "SELECT id, name, email, password, status
                FROM customers
                WHERE email = ?
                LIMIT 1";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {

            $error = 'Database error. Please check your database.';

        } else {

            mysqli_stmt_bind_param($stmt, "s", $email);

            if (mysqli_stmt_execute($stmt)) {

                $result = mysqli_stmt_get_result($stmt);
                $customer = mysqli_fetch_assoc($result);

                if (!$customer) {

                    $error = 'Invalid email or password.';

                } elseif ($customer['status'] !== 'active') {

                    $error = 'Your account is blocked. Please contact admin.';

                } elseif (password_verify(
                    $password,
                    $customer['password']
                )) {

                    session_regenerate_id(true);

                    $_SESSION['customer_id'] = $customer['id'];
                    $_SESSION['customer_name'] = $customer['name'];
                    $_SESSION['customer_email'] = $customer['email'];

                    mysqli_stmt_close($stmt);

                    header('Location: index.php');
                    exit;

                } else {

                    $error = 'Invalid email or password.';
                }

            } else {

                $error = 'Login failed. Please try again.';
            }

            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Login | Wellness Bite</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: Arial, sans-serif;
            background: #ffffff;
        }

        .login-box {
            width: 100%;
            max-width: 400px;
            padding: 30px;
            background: #ffffff;
            border-radius: 17px;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.23);
        }

        h2 {
            margin: 0 0 30px;
            text-align: center;
            color: #20a746;
            font-size: 24px;
        }

        .input-field {
            display: block;
            width: 100%;
            height: 44px;
            margin-bottom: 20px;
            padding: 10px 12px;
            border: 1px solid #cccccc;
            border-radius: 10px;
            outline: none;
            font-size: 16px;
        }

        .input-field:focus {
            border-color: #28a745;
        }

        .login-btn {
            width: 100%;
            height: 42px;
            border: none;
            border-radius: 9px;
            background: #28a745;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
        }

        .login-btn:hover {
            background: #218838;
        }

        .error {
            padding: 10px;
            margin-bottom: 18px;
            border-radius: 6px;
            background: #ffebee;
            color: #b00020;
            font-size: 14px;
            overflow-wrap: anywhere;
        }

        .register {
            margin-top: 25px;
            text-align: center;
            font-size: 16px;
        }

        a {
            color: #20a746;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .back-home {
            margin-top: 17px;
            text-align: center;
            font-size: 16px;
        }

        @media (max-width: 480px) {
            .login-box {
                padding: 25px 20px;
            }
        }
    </style>
</head>

<body>

<div class="login-box">

    <h2>User Login</h2>

    <?php if ($error !== ''): ?>
        <div class="error">
            <?= htmlspecialchars(
                $error,
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </div>
    <?php endif; ?>

    <form action="login.php" method="POST">

        <input
            type="email"
            name="email"
            class="input-field"
            placeholder="Enter Email"
            value="<?= htmlspecialchars(
                $_POST['email'] ?? '',
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
            required
        >

        <input
            type="password"
            name="password"
            class="input-field"
            placeholder="Enter Password"
            required
        >

        <button type="submit" class="login-btn">
            Login
        </button>

    </form>

    <div class="register">
        Don't have an account?
        <a href="register.php">Register</a>
    </div>

    <div class="back-home">
        <a href="index.php">&larr; Back to Home</a>
    </div>

</div>

</body>
</html>
