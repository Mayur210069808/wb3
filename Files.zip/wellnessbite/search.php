<?php
require_once 'conn.php';

$search = $_GET['search'] ?? '';
$search = mysqli_real_escape_string($conn, $search);

$query = "SELECT * FROM foods
          WHERE name LIKE '%$search%'
          AND status = 'active'
          ORDER BY id DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Search Food - Wellness Bite</title>

<style>

body{
    font-family:Arial,sans-serif;
    background:#f5f5f5;
    margin:0;
    padding:20px;
}

h2{
    text-align:center;
    color:#282C3F;
    margin-bottom:25px;
}

.food-container{
    display:flex;
    flex-wrap:wrap;
    justify-content:center;
    gap:20px;
}

.food-card{
    width:300px;
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.15);
    box-sizing:border-box;
}

.food-card img{
    width:100%;
    height:200px;
    object-fit:cover;
    border-radius:8px;
    display:block;
}

.no-image{
    width:100%;
    height:200px;
    background:#eeeeee;
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#777;
}

.food-card h3{
    margin:12px 0 8px;
    color:#282C3F;
}

.price{
    font-size:18px;
    font-weight:bold;
    color:#FC8019;
}

.order-btn{
    display:block;
    text-align:center;
    margin-top:15px;
    padding:11px;
    background:#FC8019;
    color:white;
    text-decoration:none;
    border-radius:5px;
    font-weight:bold;
}

.order-btn:hover{
    background:#e66f0a;
}

</style>

</head>

<body>

<h2>
    Search Results
</h2>


<div class="food-container">


<?php if (mysqli_num_rows($result) > 0): ?>


    <?php while ($food = mysqli_fetch_assoc($result)): ?>


        <?php

        /*
        ---------------------------------------
        GET FOOD IMAGE
        ---------------------------------------
        */

        $image = trim($food['image'] ?? '');

        $imagePath = '';

        if ($image != '') {

            /*
            Remove any existing folder path
            */

            $image = str_replace(
                '\\',
                '/',
                $image
            );

            $image = basename($image);


            /*
            Check common image extensions
            */

            $possibleImages = [

                'images/' . $image,

                'images/foods/' . $image,

                'images/food/' . $image,

                'uploads/' . $image,

                'uploads/foods/' . $image

            ];


            /*
            Find the image that actually exists
            */

            foreach ($possibleImages as $possibleImage) {

                if (file_exists($possibleImage)) {

                    $imagePath = $possibleImage;

                    break;

                }

            }


            /*
            If exact filename was not found,
            try common extensions.
            */

            if ($imagePath == '') {

                $imageName = pathinfo(
                    $image,
                    PATHINFO_FILENAME
                );

                $extensions = [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp'
                ];


                foreach ($extensions as $extension) {

                    $testImage = 'images/'
                        . $imageName
                        . '.'
                        . $extension;


                    if (file_exists($testImage)) {

                        $imagePath = $testImage;

                        break;

                    }

                }

            }

        }

        ?>


        <div class="food-card">


            <!-- FOOD IMAGE -->

            <?php if ($imagePath != ''): ?>

                <img
                    src="<?php echo htmlspecialchars($imagePath); ?>"
                    alt="<?php echo htmlspecialchars($food['name']); ?>"
                >

            <?php else: ?>

                <div class="no-image">
                    Image Not Available
                </div>

            <?php endif; ?>


            <!-- FOOD NAME -->

            <h3>
                <?php echo htmlspecialchars($food['name']); ?>
            </h3>


            <!-- FOOD PRICE -->

            <p class="price">
                ₹<?php echo number_format(
                    (float)$food['price'],
                    2
                ); ?>
            </p>


            <!-- ORDER NOW -->

            <a
                href="payment.php?food_id=<?php echo (int)$food['id']; ?>"
                class="order-btn"
            >
                Order Now
            </a>


        </div>


    <?php endwhile; ?>


<?php else: ?>


    <p style="text-align:center;">
        No food found.
    </p>


<?php endif; ?>


</div>


</body>

</html>

