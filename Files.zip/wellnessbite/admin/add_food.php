<?php
require_once 'includes/auth.php';
$pageTitle = "Add Food";

$message = "";
$msgType = "success";

if (isset($_POST['add_food'])) {
    $category_id = (int) $_POST['category_id'];
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (float) $_POST['price'];
    $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
    $image = '';

    if ($name === "" || $category_id <= 0 || $price <= 0) {
        $message = "Please fill in name, category and a valid price.";
        $msgType = "error";
    } else {

        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $filename = uniqid('food_') . '.' . $ext;
                $destDir = __DIR__ . '/../uploads/';
                if (!is_dir($destDir)) mkdir($destDir, 0755, true);
                if (move_uploaded_file($_FILES['image']['tmp_name'], $destDir . $filename)) {
                    $image = 'uploads/' . $filename;
                }
            } else {
                $message = "Image must be jpg, jpeg, png or webp.";
                $msgType = "error";
            }
        }

        if ($msgType !== "error") {
            $stmt = mysqli_prepare($conn, "INSERT INTO foods (category_id, name, description, price, image, status) VALUES (?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "issdss", $category_id, $name, $description, $price, $image, $status);
            if (mysqli_stmt_execute($stmt)) {
                $message = "Food item added successfully.";
                $_POST = [];
            } else {
                $message = "Something went wrong. Please try again.";
                $msgType = "error";
            }
        }
    }
}

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $msgType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Add New Food Item</h2>
    <form method="POST" enctype="multipart/form-data" class="form-grid">

        <div class="field">
            <label>Food Name</label>
            <input type="text" name="name" placeholder="e.g. Mango Smoothie" required>
        </div>

        <div class="field">
            <label>Category</label>
            <select name="category_id" required>
                <option value="">Select category</option>
                <?php mysqli_data_seek($categories, 0); while ($c = mysqli_fetch_assoc($categories)): ?>
                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['icon'] . ' ' . $c['name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="field">
            <label>Price (₹)</label>
            <input type="number" step="0.01" min="0" name="price" placeholder="150" required>
        </div>

        <div class="field">
            <label>Status</label>
            <select name="status">
                <option value="active">Active (visible on site)</option>
                <option value="inactive">Inactive (hidden)</option>
            </select>
        </div>

        <div class="field full">
            <label>Description</label>
            <textarea name="description" rows="3" placeholder="Short description shown to customers"></textarea>
        </div>

        <div class="field full">
            <label>Food Image</label>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
        </div>

        <div class="field full">
            <button type="submit" name="add_food" class="btn btn-primary">Add Food Item</button>
        </div>

    </form>
</div>

<?php include 'includes/footer.php'; ?>
