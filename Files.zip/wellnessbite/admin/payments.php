<?php
require_once 'includes/auth.php';
$pageTitle = "Manage Payments";

// Mark payment as paid / refunded
if (isset($_POST['update_payment'])) {
    $id = (int) $_POST['payment_id'];
    $status = in_array($_POST['status'], ['Pending','Paid','Failed','Refunded']) ? $_POST['status'] : 'Pending';
    $stmt = mysqli_prepare($conn, "UPDATE payments SET status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $status, $id);
    mysqli_stmt_execute($stmt);
    header("Location: payments.php?msg=updated");
    exit();
}

$message = ($_GET['msg'] ?? '') === 'updated' ? "Payment status updated." : "";

$totalPaid = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) t FROM payments WHERE status='Paid'"))['t'];
$totalPending = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) t FROM payments WHERE status='Pending'"))['t'];

$payments = mysqli_query($conn, "
    SELECT p.*, o.customer_name, o.food_name
    FROM payments p
    LEFT JOIN orders o ON p.order_id = o.id
    ORDER BY p.id DESC
");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="cards">
    <div class="stat-card">
        <h3>₹<?php echo number_format($totalPaid, 2); ?></h3>
        <p>Total Collected</p>
    </div>
    <div class="stat-card">
        <h3>₹<?php echo number_format($totalPending, 2); ?></h3>
        <p>Pending Payments</p>
    </div>
</div>

<div class="panel">
    <h2>All Payments</h2>
    <table>
        <tr>
            <th>Payment #</th>
            <th>Order</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
            <th>Date</th>
            <th>Update</th>
        </tr>
        <?php if (mysqli_num_rows($payments) === 0): ?>
            <tr><td colspan="8" class="empty-state">No payments recorded yet.</td></tr>
        <?php endif; ?>
        <?php while ($p = mysqli_fetch_assoc($payments)):
            $statusClass = 'badge-' . strtolower($p['status']);
        ?>
        <tr>
            <td>#<?php echo $p['id']; ?></td>
            <td>#<?php echo $p['order_id']; ?> — <?php echo htmlspecialchars($p['food_name'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($p['customer_name'] ?? '—'); ?></td>
            <td>₹<?php echo number_format($p['amount'], 2); ?></td>
            <td><?php echo htmlspecialchars($p['method']); ?></td>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($p['status']); ?></span></td>
            <td><?php echo date('d M Y', strtotime($p['created_at'])); ?></td>
            <td>
                <form method="POST" style="display:flex;gap:6px;">
                    <input type="hidden" name="payment_id" value="<?php echo $p['id']; ?>">
                    <select name="status" style="padding:6px;border-radius:6px;border:1px solid #ddd;">
                        <?php foreach (['Pending','Paid','Failed','Refunded'] as $s): ?>
                            <option value="<?php echo $s; ?>" <?php echo $p['status'] === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="update_payment" class="btn btn-primary btn-sm">Save</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
