
<?php
require_once 'includes/auth.php';
$pageTitle = "Manage Orders";

// Optional filter by status
$filter = $_GET['status'] ?? '';
$sql = "SELECT * FROM orders";
if ($filter !== '') {
    $filterSafe = mysqli_real_escape_string($conn, $filter);
    $sql .= " WHERE status = '$filterSafe'";
}
$sql .= " ORDER BY id DESC";
$orders = mysqli_query($conn, $sql);

include 'includes/header.php';
?>

<div class="panel">
    <h2>All Orders</h2>

    <form method="GET" style="margin-bottom:18px;max-width:260px;">
        <select name="status" class="field" onchange="this.form.submit()" style="width:100%;padding:10px;border-radius:8px;border:1px solid #ddd;">
            <option value="">All Statuses</option>
            <?php foreach (['Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled'] as $s): ?>
                <option value="<?php echo $s; ?>" <?php echo $filter === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
            <?php endforeach; ?>
        </select>
    </form>

    <table>
        <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Mobile</th>
            <th>Food</th>
            <th>Amount</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
        <?php if (mysqli_num_rows($orders) === 0): ?>
            <tr><td colspan="8" class="empty-state">No orders found.</td></tr>
        <?php endif; ?>
        <?php while ($o = mysqli_fetch_assoc($orders)):
            $statusClass = 'badge-' . strtolower(str_replace(' ', '-', $o['status']));
        ?>
        <tr>
            <td>#<?php echo $o['id']; ?></td>
            <td><?php echo htmlspecialchars($o['customer_name']); ?></td>
            <td><?php echo htmlspecialchars($o['mobile']); ?></td>
            <td><?php echo htmlspecialchars($o['food_name']); ?></td>
            <td>₹<?php echo number_format($o['price'], 2); ?></td>
            <td><?php echo htmlspecialchars($o['payment_method']); ?></td>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($o['status']); ?></span></td>
            <td><?php echo date('d M Y, h:i A', strtotime($o['created_at'])); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
