<?php
require_once 'includes/auth.php';
$pageTitle = "Manage Offers";

$message = "";
$msgType = "success";

if (isset($_POST['add_offer'])) {
    $title = trim($_POST['title']);
    $code = strtoupper(trim($_POST['code']));
    $discount = (int) $_POST['discount_percent'];
    $description = trim($_POST['description']);
    $validFrom = $_POST['valid_from'] ?: null;
    $validTo = $_POST['valid_to'] ?: null;

    if ($title === "" || $code === "" || $discount <= 0) {
        $message = "Please fill in title, code and a valid discount percentage.";
        $msgType = "error";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO offers (title, code, discount_percent, description, valid_from, valid_to) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssisss", $title, $code, $discount, $description, $validFrom, $validTo);
        if (mysqli_stmt_execute($stmt)) {
            $message = "Offer created successfully.";
        } else {
            $message = "Could not create offer (code may already exist).";
            $msgType = "error";
        }
    }
}

if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $cur = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status FROM offers WHERE id = $id"));
    if ($cur) {
        $new = $cur['status'] === 'active' ? 'inactive' : 'active';
        $stmt = mysqli_prepare($conn, "UPDATE offers SET status = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new, $id);
        mysqli_stmt_execute($stmt);
    }
    header("Location: offers.php");
    exit();
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = mysqli_prepare($conn, "DELETE FROM offers WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: offers.php?msg=deleted");
    exit();
}
if (($_GET['msg'] ?? '') === 'deleted') $message = "Offer deleted.";

$offers = mysqli_query($conn, "SELECT * FROM offers ORDER BY id DESC");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $msgType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Create New Offer</h2>
    <form method="POST" class="form-grid">
        <div class="field">
            <label>Offer Title</label>
            <input type="text" name="title" placeholder="e.g. Festive Discount" required>
        </div>
        <div class="field">
            <label>Promo Code</label>
            <input type="text" name="code" placeholder="e.g. FESTIVE25" required>
        </div>
        <div class="field">
            <label>Discount (%)</label>
            <input type="number" name="discount_percent" min="1" max="100" placeholder="25" required>
        </div>
        <div class="field">
            <label>Valid From</label>
            <input type="date" name="valid_from">
        </div>
        <div class="field">
            <label>Valid To</label>
            <input type="date" name="valid_to">
        </div>
        <div class="field full">
            <label>Description</label>
            <textarea name="description" rows="2" placeholder="Shown to customers"></textarea>
        </div>
        <div class="field full">
            <button type="submit" name="add_offer" class="btn btn-primary">Create Offer</button>
        </div>
    </form>
</div>

<div class="panel">
    <h2>All Offers</h2>
    <table>
        <tr>
            <th>Title</th>
            <th>Code</th>
            <th>Discount</th>
            <th>Valid Period</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php if (mysqli_num_rows($offers) === 0): ?>
            <tr><td colspan="6" class="empty-state">No offers created yet.</td></tr>
        <?php endif; ?>
        <?php while ($o = mysqli_fetch_assoc($offers)): ?>
        <tr>
            <td><?php echo htmlspecialchars($o['title']); ?></td>
            <td><code><?php echo htmlspecialchars($o['code']); ?></code></td>
            <td><?php echo (int) $o['discount_percent']; ?>%</td>
            <td>
                <?php echo $o['valid_from'] ? date('d M Y', strtotime($o['valid_from'])) : '—'; ?>
                to
                <?php echo $o['valid_to'] ? date('d M Y', strtotime($o['valid_to'])) : '—'; ?>
            </td>
            <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo ucfirst($o['status']); ?></span></td>
            <td class="actions">
                <a href="offers.php?toggle=<?php echo $o['id']; ?>" class="btn btn-outline btn-sm">
                    <?php echo $o['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                </a>
                <a href="offers.php?delete=<?php echo $o['id']; ?>" class="btn btn-red btn-sm"
                   onclick="return confirm('Delete this offer?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
