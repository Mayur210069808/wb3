<?php
require_once 'includes/auth.php';
$pageTitle = "Update Food";

$id = (int) ($_GET['id'] ?? 0);
$stmt = mysqli_prepare($conn, "SELECT * FROM foods WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$food = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$food) {
    header("Location: manage_food.php");
    exit();
}

$message = "";
$msgType = "success";

if (isset($_POST['update_food'])) {
    $category_id = (int) $_POST['category_id'];
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = (float) $_POST['price'];
    $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
    $image = $food['image'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $filename = uniqid('food_') . '.' . $ext;
            $destDir = __DIR__ . '/../uploads/';
            if (!is_dir($destDir)) mkdir($destDir, 0755, true);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $destDir . $filename)) {
                $image = 'uploads/' . $filename;
            }
        }
    }

    $stmt2 = mysqli_prepare($conn, "UPDATE foods SET category_id=?, name=?, description=?, price=?, image=?, status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt2, "issdssi", $category_id, $name, $description, $price, $image, $status, $id);

    if (mysqli_stmt_execute($stmt2)) {
        $message = "Food item updated successfully.";
        $food = array_merge($food, [
            'category_id' => $category_id, 'name' => $name, 'description' => $description,
            'price' => $price, 'image' => $image, 'status' => $status
        ]);
    } else {
        $message = "Update failed. Please try again.";
        $msgType = "error";
    }
}

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $msgType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Edit: <?php echo htmlspecialchars($food['name']); ?></h2>
    <form method="POST" enctype="multipart/form-data" class="form-grid">

        <div class="field">
            <label>Food Name</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($food['name']); ?>" required>
        </div>

        <div class="field">
            <label>Category</label>
            <select name="category_id" required>
                <?php mysqli_data_seek($categories, 0); while ($c = mysqli_fetch_assoc($categories)): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo $c['id'] == $food['category_id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($c['icon'] . ' ' . $c['name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="field">
            <label>Price (₹)</label>
            <input type="number" step="0.01" min="0" name="price" value="<?php echo htmlspecialchars($food['price']); ?>" required>
        </div>

        <div class="field">
            <label>Status</label>
            <select name="status">
                <option value="active" <?php echo $food['status'] === 'active' ? 'selected' : ''; ?>>Active (visible on site)</option>
                <option value="inactive" <?php echo $food['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive (hidden)</option>
            </select>
        </div>

        <div class="field full">
            <label>Description</label>
            <textarea name="description" rows="3"><?php echo htmlspecialchars($food['description']); ?></textarea>
        </div>

        <?php if ($food['image']): ?>
        <div class="field">
            <label>Current Image</label>
            <img class="thumb" style="width:90px;height:90px;" src="../<?php echo htmlspecialchars($food['image']); ?>" onerror="this.src='../veg.jpg'">
        </div>
        <?php endif; ?>

        <div class="field full">
            <label>Replace Image (optional)</label>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">
        </div>

        <div class="field full">
            <button type="submit" name="update_food" class="btn btn-primary">Save Changes</button>
            <a href="manage_food.php" class="btn btn-outline">Cancel</a>
        </div>

    </form>
</div>

<?php include 'includes/footer.php'; ?>
