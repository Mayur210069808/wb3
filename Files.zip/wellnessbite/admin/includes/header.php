<?php
$current = basename($_SERVER['PHP_SELF']);
function nav_active($file, $current) {
    return $file === $current ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' : ''; ?>Wellness Bite Admin</title>
<link rel="stylesheet" href="includes/style.css">
</head>
<body>

<div class="wrap">

    <aside class="sidebar">
        <div class="brand">🍃 Wellness <span>Bite</span></div>
        <nav>
            <a href="dashboard.php" class="<?php echo nav_active('dashboard.php', $current); ?>">📊 Dashboard</a>
            <a href="categories.php" class="<?php echo nav_active('categories.php', $current); ?>">🗂️ Manage Categories</a>
            <a href="add_food.php" class="<?php echo nav_active('add_food.php', $current); ?>">➕ Add Food</a>
            <a href="manage_food.php" class="<?php echo nav_active('manage_food.php', $current) ?: nav_active('edit_food.php', $current); ?>">✏️ Update Food</a>
            <a href="manage_food.php?focus=delete" class="<?php echo $current === 'manage_food.php' && ($_GET['focus'] ?? '') === 'delete' ? 'active' : ''; ?>">🗑️ Delete Food</a>
            <a href="orders.php" class="<?php echo nav_active('orders.php', $current); ?>">🧾 Manage Orders</a>
            <a href="update_order_status.php" class="<?php echo nav_active('update_order_status.php', $current); ?>">🚚 Update Order Status</a>
            <a href="customers.php" class="<?php echo nav_active('customers.php', $current); ?>">👥 Manage Customers</a>
            <a href="payments.php" class="<?php echo nav_active('payments.php', $current); ?>">💳 Manage Payments</a>
            <a href="reports.php" class="<?php echo nav_active('reports.php', $current); ?>">📈 View Reports</a>
            <a href="offers.php" class="<?php echo nav_active('offers.php', $current); ?>">🏷️ Manage Offers</a>
            <a href="logout.php" class="logout">🚪 Logout</a>
        </nav>
    </aside>

    <main class="main">
        <div class="topbar">
            <h1><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Dashboard'; ?></h1>
            <div class="admin-name">👤 <?php echo htmlspecialchars($_SESSION['admin_username'] ?? 'Admin'); ?></div>
        </div>
