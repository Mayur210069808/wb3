<?php
session_start();

require_once __DIR__ . '/../conn.php';

if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";

if (isset($_POST['login'])) {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = mysqli_prepare(
        $conn,
        "SELECT id, username, password FROM admin WHERE username = ? LIMIT 1"
    );

    if ($stmt) {

        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) === 1) {

            $admin = mysqli_fetch_assoc($result);

            if (password_verify($password, $admin['password'])) {

                session_regenerate_id(true);

                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_username'] = $admin['username'];

                header("Location: dashboard.php");
                exit();

            } else {
                $error = "Invalid Username or Password!";
            }

        } else {
            $error = "Invalid Username or Password!";
        }

        mysqli_stmt_close($stmt);

    } else {
        $error = "Unable to process login. Please check your database.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Wellness Bite - Admin Login</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;

            background:
                linear-gradient(
                    rgba(0, 0, 0, 0.30),
                    rgba(0, 0, 0, 0.30)
                ),
                url("../healthy-food-bg.png");

            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        .login-box {
            width: 380px;
            max-width: 100%;
            padding: 35px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.40);
            backdrop-filter: blur(5px);
            animation: fadeIn 0.8s ease;
        }

        .login-box h1 {
            text-align: center;
            color: #ff7200;
            margin-bottom: 8px;
            font-size: 30px;
            font-weight: bold;
        }

        .login-box h3 {
            text-align: center;
            color: #555;
            margin-bottom: 25px;
            font-size: 18px;
        }

        .input-box {
            margin-bottom: 18px;
        }

        .input-box label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #333;
        }

        .input-box input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ccc;
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .input-box input:focus {
            border-color: #ff7200;
            box-shadow: 0 0 8px rgba(255, 114, 0, 0.30);
        }

        .login-btn {
            width: 100%;
            padding: 13px;
            border: none;
            border-radius: 8px;
            background: linear-gradient(135deg, #ff7200, #ff9800);
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-btn:hover {
            background: linear-gradient(135deg, #e65f00, #ff7200);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(255, 114, 0, 0.35);
        }

        .error {
            color: #d60000;
            background: #ffe5e5;
            padding: 10px;
            border-radius: 7px;
            text-align: center;
            margin-bottom: 15px;
            font-size: 14px;
        }

        .brand {
            text-align: center;
            margin-top: 20px;
            color: #777;
            font-size: 14px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 500px) {
            .login-box {
                padding: 28px;
            }

            .login-box h1 {
                font-size: 26px;
            }
        }
    </style>
</head>

<body>

    <div class="login-box">

        <h1>Wellness Bite</h1>
        <h3>Admin Login</h3>

        <?php if ($error !== "") { ?>
            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php } ?>

        <form method="POST" action="">

            <div class="input-box">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Enter username"
                    autocomplete="username"
                    required
                >
            </div>

            <div class="input-box">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button
                type="submit"
                name="login"
                class="login-btn"
            >
                Login
            </button>

        </form>

        <div class="brand">
            © 2026 Wellness Bite
        </div>

    </div>

</body>
</html>

