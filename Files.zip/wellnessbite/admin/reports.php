<?php
require_once 'includes/auth.php';
$pageTitle = "View Reports";

$totalRevenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) t FROM payments WHERE status='Paid'"))['t'];
$totalOrders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM orders"))['c'];
$avgOrderValue = $totalOrders > 0 ? $totalRevenue / max(1, mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM payments WHERE status='Paid'"))['c']) : 0;

// Best selling foods
$topFoods = mysqli_query($conn, "
    SELECT food_name, COUNT(*) AS times_ordered, SUM(price) AS revenue
    FROM orders
    GROUP BY food_name
    ORDER BY times_ordered DESC
    LIMIT 8
");

// Orders by category
$byCategory = mysqli_query($conn, "
    SELECT c.name AS category_name, COUNT(o.id) AS order_count, COALESCE(SUM(o.price),0) AS revenue
    FROM orders o
    LEFT JOIN foods f ON o.food_id = f.id
    LEFT JOIN categories c ON f.category_id = c.id
    GROUP BY c.name
    ORDER BY revenue DESC
");

// Orders by status
$byStatus = mysqli_query($conn, "SELECT status, COUNT(*) c FROM orders GROUP BY status");

// Monthly revenue (last 6 months)
$byMonth = mysqli_query($conn, "
    SELECT DATE_FORMAT(created_at, '%b %Y') AS month, COALESCE(SUM(amount),0) AS revenue
    FROM payments
    WHERE status = 'Paid'
    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ORDER BY DATE_FORMAT(created_at, '%Y-%m') DESC
    LIMIT 6
");

include 'includes/header.php';
?>

<div class="cards">
    <div class="stat-card">
        <h3>₹<?php echo number_format($totalRevenue, 2); ?></h3>
        <p>Total Revenue</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $totalOrders; ?></h3>
        <p>Total Orders</p>
    </div>
    <div class="stat-card">
        <h3>₹<?php echo number_format($avgOrderValue, 2); ?></h3>
        <p>Average Order Value</p>
    </div>
</div>

<div class="panel">
    <h2>Best-Selling Food Items</h2>
    <table>
        <tr><th>Food</th><th>Times Ordered</th><th>Revenue</th></tr>
        <?php if (mysqli_num_rows($topFoods) === 0): ?>
            <tr><td colspan="3" class="empty-state">No order data yet.</td></tr>
        <?php endif; ?>
        <?php while ($f = mysqli_fetch_assoc($topFoods)): ?>
        <tr>
            <td><?php echo htmlspecialchars($f['food_name']); ?></td>
            <td><?php echo $f['times_ordered']; ?></td>
            <td>₹<?php echo number_format($f['revenue'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="panel">
    <h2>Revenue by Category</h2>
    <table>
        <tr><th>Category</th><th>Orders</th><th>Revenue</th></tr>
        <?php if (mysqli_num_rows($byCategory) === 0): ?>
            <tr><td colspan="3" class="empty-state">No order data yet.</td></tr>
        <?php endif; ?>
        <?php while ($c = mysqli_fetch_assoc($byCategory)): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['category_name'] ?? 'Uncategorized'); ?></td>
            <td><?php echo $c['order_count']; ?></td>
            <td>₹<?php echo number_format($c['revenue'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="panel">
    <h2>Orders by Status</h2>
    <table>
        <tr><th>Status</th><th>Count</th></tr>
        <?php while ($s = mysqli_fetch_assoc($byStatus)):
            $statusClass = 'badge-' . strtolower(str_replace(' ', '-', $s['status']));
        ?>
        <tr>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($s['status']); ?></span></td>
            <td><?php echo $s['c']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<div class="panel">
    <h2>Revenue - Last 6 Months</h2>
    <table>
        <tr><th>Month</th><th>Revenue</th></tr>
        <?php if (mysqli_num_rows($byMonth) === 0): ?>
            <tr><td colspan="2" class="empty-state">No payment data yet.</td></tr>
        <?php endif; ?>
        <?php while ($m = mysqli_fetch_assoc($byMonth)): ?>
        <tr>
            <td><?php echo htmlspecialchars($m['month']); ?></td>
            <td>₹<?php echo number_format($m['revenue'], 2); ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
