<?php
require_once 'includes/auth.php';
$pageTitle = "Manage Customers";

// Toggle block/unblock
if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $cur = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status FROM customers WHERE id = $id"));
    if ($cur) {
        $new = $cur['status'] === 'active' ? 'blocked' : 'active';
        $stmt = mysqli_prepare($conn, "UPDATE customers SET status = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new, $id);
        mysqli_stmt_execute($stmt);
    }
    header("Location: customers.php");
    exit();
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = mysqli_prepare($conn, "DELETE FROM customers WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: customers.php?msg=deleted");
    exit();
}

$message = ($_GET['msg'] ?? '') === 'deleted' ? "Customer removed." : "";

$customers = mysqli_query($conn, "
    SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS order_count
    FROM customers c
    ORDER BY c.id DESC
");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Registered Customers</h2>
    <table>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Orders</th>
            <th>Status</th>
            <th>Joined</th>
            <th>Actions</th>
        </tr>
        <?php if (mysqli_num_rows($customers) === 0): ?>
            <tr><td colspan="7" class="empty-state">No customers have registered yet.</td></tr>
        <?php endif; ?>
        <?php while ($c = mysqli_fetch_assoc($customers)): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['name']); ?></td>
            <td><?php echo htmlspecialchars($c['email']); ?></td>
            <td><?php echo htmlspecialchars($c['mobile']); ?></td>
            <td><?php echo (int) $c['order_count']; ?></td>
            <td><span class="badge badge-<?php echo $c['status']; ?>"><?php echo ucfirst($c['status']); ?></span></td>
            <td><?php echo date('d M Y', strtotime($c['created_at'])); ?></td>
            <td class="actions">
                <a href="customers.php?toggle=<?php echo $c['id']; ?>" class="btn btn-outline btn-sm">
                    <?php echo $c['status'] === 'active' ? 'Block' : 'Unblock'; ?>
                </a>
                <a href="customers.php?delete=<?php echo $c['id']; ?>" class="btn btn-red btn-sm"
                   onclick="return confirm('Delete this customer?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
