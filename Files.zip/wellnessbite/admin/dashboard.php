<?php
require_once 'includes/auth.php';
$pageTitle = "Dashboard";

$totalFoods     = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM foods"))['c'];
$totalOrders    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM orders"))['c'];
$totalCustomers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM customers"))['c'];
$totalRevenue   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='Paid'"))['r'];
$pendingOrders  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM orders WHERE status='Pending'"))['c'];
$activeOffers   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM offers WHERE status='active'"))['c'];

include 'includes/header.php';
?>

<div class="cards">
    <div class="stat-card">
        <h3><?php echo $totalOrders; ?></h3>
        <p>Total Orders</p>
    </div>
    <div class="stat-card">
        <h3>₹<?php echo number_format($totalRevenue, 2); ?></h3>
        <p>Revenue Collected</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $totalCustomers; ?></h3>
        <p>Registered Customers</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $totalFoods; ?></h3>
        <p>Food Items</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $pendingOrders; ?></h3>
        <p>Pending Orders</p>
    </div>
    <div class="stat-card">
        <h3><?php echo $activeOffers; ?></h3>
        <p>Active Offers</p>
    </div>
</div>

<div class="panel">
    <h2>Recent Orders</h2>
    <table>
        <tr>
            <th>#</th>
            <th>Customer</th>
            <th>Food</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
        <?php
        $recent = mysqli_query($conn, "SELECT * FROM orders ORDER BY id DESC LIMIT 8");
        if (mysqli_num_rows($recent) === 0) {
            echo '<tr><td colspan="6" class="empty-state">No orders yet.</td></tr>';
        }
        while ($row = mysqli_fetch_assoc($recent)) {
            $statusClass = 'badge-' . strtolower(str_replace(' ', '-', $row['status']));
            echo "<tr>
                <td>#{$row['id']}</td>
                <td>" . htmlspecialchars($row['customer_name']) . "</td>
                <td>" . htmlspecialchars($row['food_name']) . "</td>
                <td>₹" . number_format($row['price'], 2) . "</td>
                <td><span class='badge {$statusClass}'>" . htmlspecialchars($row['status']) . "</span></td>
                <td>" . date('d M Y', strtotime($row['created_at'])) . "</td>
            </tr>";
        }
        ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>


<a href="/wellnessbite/admin/logout.php" class="logout-btn">Logout</a>

<style>
.logout-btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: #e74c3c;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}
.logout-btn:hover {
    background-color: #c0392b;
}
</style>
