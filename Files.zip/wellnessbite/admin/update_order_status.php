<?php
require_once 'includes/auth.php';
$pageTitle = "Update Order Status";

$statuses = ['Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled'];

if (isset($_POST['update_status'])) {
    $orderId = (int) $_POST['order_id'];
    $newStatus = in_array($_POST['status'], $statuses) ? $_POST['status'] : 'Pending';

    $stmt = mysqli_prepare($conn, "UPDATE orders SET status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $newStatus, $orderId);
    mysqli_stmt_execute($stmt);

    // Keep payment record status roughly in sync
    if ($newStatus === 'Cancelled') {
        $pStmt = mysqli_prepare($conn, "UPDATE payments SET status = 'Refunded' WHERE order_id = ? AND status = 'Paid'");
        mysqli_stmt_bind_param($pStmt, "i", $orderId);
        mysqli_stmt_execute($pStmt);
    }

    header("Location: update_order_status.php?msg=updated");
    exit();
}

$message = ($_GET['msg'] ?? '') === 'updated' ? "Order status updated." : "";

$orders = mysqli_query($conn, "SELECT * FROM orders WHERE status != 'Delivered' AND status != 'Cancelled' ORDER BY id DESC");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Active Orders</h2>
    <p style="color:#888;margin-bottom:15px;font-size:14px;">Delivered and cancelled orders are hidden here. See "Manage Orders" for the full list.</p>

    <table>
        <tr>
            <th>Order #</th>
            <th>Customer</th>
            <th>Food</th>
            <th>Amount</th>
            <th>Current Status</th>
            <th>Change Status</th>
        </tr>
        <?php if (mysqli_num_rows($orders) === 0): ?>
            <tr><td colspan="6" class="empty-state">No active orders right now. 🎉</td></tr>
        <?php endif; ?>
        <?php while ($o = mysqli_fetch_assoc($orders)):
            $statusClass = 'badge-' . strtolower(str_replace(' ', '-', $o['status']));
        ?>
        <tr>
            <td>#<?php echo $o['id']; ?></td>
            <td><?php echo htmlspecialchars($o['customer_name']); ?></td>
            <td><?php echo htmlspecialchars($o['food_name']); ?></td>
            <td>₹<?php echo number_format($o['price'], 2); ?></td>
            <td><span class="badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($o['status']); ?></span></td>
            <td>
                <form method="POST" style="display:flex;gap:8px;">
                    <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                    <select name="status" style="padding:8px;border-radius:6px;border:1px solid #ddd;">
                        <?php foreach ($statuses as $s): ?>
                            <option value="<?php echo $s; ?>" <?php echo $o['status'] === $s ? 'selected' : ''; ?>><?php echo $s; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" name="update_status" class="btn btn-primary btn-sm">Update</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
