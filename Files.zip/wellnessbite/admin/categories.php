<?php
require_once 'includes/auth.php';
$pageTitle = "Manage Categories";

$message = "";
$msgType = "success";

// Add category
if (isset($_POST['add_category'])) {
    $name = trim($_POST['name']);
    $icon = trim($_POST['icon']) ?: '🍽️';
    $slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $name), '-'));

    if ($name === "") {
        $message = "Category name is required.";
        $msgType = "error";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO categories (name, slug, icon) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sss", $name, $slug, $icon);
        if (mysqli_stmt_execute($stmt)) {
            $message = "Category added successfully.";
        } else {
            $message = "Could not add category (slug may already exist).";
            $msgType = "error";
        }
    }
}

// Update category
if (isset($_POST['update_category'])) {
    $id = (int) $_POST['id'];
    $name = trim($_POST['name']);
    $icon = trim($_POST['icon']) ?: '🍽️';

    $stmt = mysqli_prepare($conn, "UPDATE categories SET name = ?, icon = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ssi", $name, $icon, $id);
    mysqli_stmt_execute($stmt);
    $message = "Category updated.";
}

// Delete category
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: categories.php?msg=deleted");
    exit();
}
if (($_GET['msg'] ?? '') === 'deleted') {
    $message = "Category deleted.";
}

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $msgType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>Add New Category</h2>
    <form method="POST" class="form-grid">
        <div class="field">
            <label>Category Name</label>
            <input type="text" name="name" placeholder="e.g. Desserts" required>
        </div>
        <div class="field">
            <label>Icon / Emoji</label>
            <input type="text" name="icon" placeholder="🍰">
        </div>
        <div class="field full">
            <button type="submit" name="add_category" class="btn btn-primary">Add Category</button>
        </div>
    </form>
</div>

<div class="panel">
    <h2>All Categories</h2>
    <table>
        <tr>
            <th>Icon</th>
            <th>Name</th>
            <th>Slug</th>
            <th>Food Items</th>
            <th>Actions</th>
        </tr>
        <?php
        $cats = mysqli_query($conn, "SELECT c.*, (SELECT COUNT(*) FROM foods f WHERE f.category_id = c.id) AS food_count FROM categories c ORDER BY c.id");
        while ($cat = mysqli_fetch_assoc($cats)):
        ?>
        <tr>
            <form method="POST">
            <td style="font-size:22px;"><?php echo htmlspecialchars($cat['icon']); ?></td>
            <td><?php echo htmlspecialchars($cat['name']); ?></td>
            <td><?php echo htmlspecialchars($cat['slug']); ?></td>
            <td><?php echo (int) $cat['food_count']; ?></td>
            <td class="actions">
                <a href="categories.php?delete=<?php echo $cat['id']; ?>"
                   class="btn btn-red btn-sm"
                   onclick="return confirm('Delete this category? Its food items will also be removed.');">Delete</a>
            </td>
            </form>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
