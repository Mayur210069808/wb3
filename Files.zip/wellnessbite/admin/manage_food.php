<?php
require_once 'includes/auth.php';
$pageTitle = "Update / Delete Food";

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];

    $res = mysqli_query($conn, "SELECT image FROM foods WHERE id = " . $id);
    if ($row = mysqli_fetch_assoc($res)) {
        if ($row['image'] && strpos($row['image'], 'uploads/') === 0 && file_exists(__DIR__ . '/../' . $row['image'])) {
            @unlink(__DIR__ . '/../' . $row['image']);
        }
    }

    $stmt = mysqli_prepare($conn, "DELETE FROM foods WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    header("Location: manage_food.php?msg=deleted");
    exit();
}

$message = ($_GET['msg'] ?? '') === 'deleted' ? "Food item deleted." : "";

$foods = mysqli_query($conn, "
    SELECT f.*, c.name AS category_name
    FROM foods f
    LEFT JOIN categories c ON f.category_id = c.id
    ORDER BY f.id DESC
");

include 'includes/header.php';
?>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="panel">
    <h2>All Food Items</h2>
    <table>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php if (mysqli_num_rows($foods) === 0): ?>
            <tr><td colspan="6" class="empty-state">No food items yet. Go to "Add Food" to create one.</td></tr>
        <?php endif; ?>
        <?php while ($f = mysqli_fetch_assoc($foods)):
            $imgSrc = $f['image'] ? ('../' . $f['image']) : '../veg.jpg';
        ?>
        <tr>
            <td><img class="thumb" src="<?php echo htmlspecialchars($imgSrc); ?>" alt="<?php echo htmlspecialchars($f['name']); ?>" onerror="this.src='../veg.jpg'"></td>
            <td><?php echo htmlspecialchars($f['name']); ?></td>
            <td><?php echo htmlspecialchars($f['category_name'] ?? '—'); ?></td>
            <td>₹<?php echo number_format($f['price'], 2); ?></td>
            <td><span class="badge badge-<?php echo $f['status']; ?>"><?php echo ucfirst($f['status']); ?></span></td>
            <td class="actions">
                <a href="edit_food.php?id=<?php echo $f['id']; ?>" class="btn btn-outline btn-sm">Edit</a>
                <a href="manage_food.php?delete=<?php echo $f['id']; ?>" class="btn btn-red btn-sm"
                   onclick="return confirm('Delete this food item?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
