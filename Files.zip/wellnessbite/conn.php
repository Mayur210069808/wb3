<?php
// Shared database connection for Wellness Bite (site + admin panel)
// XAMPP defaults: host localhost, user root, no password
$conn = mysqli_connect("localhost", "root", "", "wellnessbite");

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");
?>
