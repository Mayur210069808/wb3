<?php
session_start();
require_once 'conn.php';

// Pull a few active items to feature on the homepage
$popular = mysqli_query(
    $conn,
    "SELECT * FROM foods WHERE status = 'active' ORDER BY id DESC LIMIT 3"
);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Wellness Bite</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', sans-serif;
    scroll-behavior: smooth;
}


/* =========================
   VARIABLES
========================= */

:root {
    --primary: #FC8019;
    --secondary: #FFB347;
    --dark: #282C3F;
    --light: #FFFFFF;
}


/* =========================
   BODY
========================= */

body {
    overflow-x: hidden;
    background: #f8f8f8;
}


/* =========================
   NAVBAR
========================= */

.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;

    padding: 20px 60px;

    background: rgba(255, 255, 255, 0.95);

    position: fixed;
    width: 100%;
    top: 0;

    z-index: 999;

    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}


.logo {
    font-size: 32px;
    font-weight: bold;
    color: var(--primary);
}


.navbar ul {
    display: flex;
    list-style: none;
}


.navbar ul li {
    margin-left: 25px;
}


.navbar ul li a {
    text-decoration: none;
    color: var(--dark);
    font-weight: 600;
    transition: 0.3s;
}


.navbar ul li a:hover {
    color: var(--primary);
}


.navbar ul li a.admin-link {
    background: var(--dark);
    color: #fff;

    padding: 8px 16px;

    border-radius: 6px;
    font-size: 14px;
}


.navbar ul li a.admin-link:hover {
    background: var(--primary);
    color: #fff;
}


/* =========================
   HERO SECTION
========================= */

.hero {

    width: 100%;
    height: 100vh;

    /* NEW BACKGROUND IMAGE */
    background:
        linear-gradient(
            rgba(0, 0, 0, 0.45),
            rgba(0, 0, 0, 0.45)
        ),
        url("images/bgimage.png");

    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;

    display: flex;
    justify-content: center;
    align-items: center;

    text-align: center;

    color: white;
}


/* =========================
   HERO CONTENT
========================= */

.hero-content {
    animation: fadeIn 1.5s ease;
}


.hero h1 {
    font-size: 65px;
    margin-bottom: 15px;
}


.hero p {
    font-size: 22px;
    margin-bottom: 25px;
}


/* =========================
   BUTTON
========================= */

.btn {
    display: inline-block;

    padding: 14px 28px;

    background: var(--primary);
    color: white;

    text-decoration: none;

    border-radius: 8px;

    margin: 8px;

    transition: 0.3s;
}


.btn:hover {
    transform: scale(1.05);
    background: #e86d0b;
}


/* =========================
   SEARCH BOX
========================= */

.search-box {
    margin-top: 20px;
}


.search-box input {
    width: 350px;

    padding: 15px;

    border: none;

    border-radius: 10px;

    outline: none;
}


.search-box button {

    padding: 15px 25px;

    border: none;

    border-radius: 10px;

    background: var(--primary);
    color: white;

    cursor: pointer;

    transition: 0.3s;
}


.search-box button:hover {
    background: #e86d0b;
}


/* =========================
   SECTIONS
========================= */

.section {
    padding: 80px 40px;
    background: white;
}


.section-title {

    text-align: center;

    font-size: 36px;

    margin-bottom: 40px;

    color: var(--dark);
}


/* =========================
   CATEGORIES
========================= */

.food-categories {

    display: flex;

    justify-content: center;

    flex-wrap: wrap;

    gap: 20px;

    margin-top: 40px;
}


.category-box {

    width: 180px;
    height: 180px;

    background: #fff;

    border: 2px solid #eee;

    border-radius: 15px;

    text-align: center;

    text-decoration: none;

    color: #333;

    font-size: 20px;

    font-weight: bold;

    padding-top: 25px;

    transition: 0.4s;

    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}


.category-box:hover {

    background: #ff7a00;

    color: #fff;

    transform: translateY(-8px) scale(1.05);

    box-shadow: 0 10px 20px rgba(255, 122, 0, 0.4);
}


.category-box:active {

    background: #ff7a00;

    color: #fff;
}


/* =========================
   SERVICES
========================= */

.services {

    display: flex;

    justify-content: center;

    align-items: center;

    gap: 20px;

    flex-wrap: wrap;

    margin-top: 30px;
}


.card {

    width: 280px;

    padding: 25px;

    background: white;

    border-radius: 15px;

    text-align: center;

    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);

    transition: 0.4s;
}


.card:hover {
    transform: translateY(-10px);
}


.card h3 {

    color: var(--primary);

    margin-bottom: 10px;
}


/* =========================
   FOODS
========================= */

.foods {

    display: flex;

    justify-content: center;

    flex-wrap: wrap;

    gap: 25px;
}


.food-card {

    width: 260px;

    background: white;

    border-radius: 15px;

    overflow: hidden;

    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);

    transition: 0.4s;
}


.food-card:hover {
    transform: translateY(-10px);
}


.food-card img {

    width: 100%;

    height: 180px;

    object-fit: cover;
}


.food-card h4 {
    padding: 10px;
}


.food-card p {
    padding: 0 10px 15px;
}


/* =========================
   STATS
========================= */

.stats {

    display: flex;

    justify-content: center;

    gap: 80px;

    flex-wrap: wrap;

    text-align: center;

    background: var(--primary);

    color: white;

    padding: 60px;
}


.stats h1 {
    font-size: 45px;
}


/* =========================
   REVIEWS
========================= */

.reviews {

    display: flex;

    justify-content: center;

    gap: 25px;

    flex-wrap: wrap;
}


.review {

    width: 320px;

    padding: 25px;

    background: white;

    border-radius: 15px;

    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}


/* =========================
   FOOTER
========================= */

.footer {

    background: #222;

    color: white;

    text-align: center;

    padding: 25px;
}


/* =========================
   ANIMATION
========================= */

@keyframes fadeIn {

    from {

        opacity: 0;

        transform: translateY(40px);
    }

    to {

        opacity: 1;

        transform: translateY(0);
    }
}


/* =========================
   MOBILE
========================= */

@media (max-width: 768px) {

    .hero h1 {
        font-size: 40px;
    }


    .hero p {
        font-size: 18px;
    }


    .search-box input {

        width: 90%;

        margin-bottom: 10px;
    }


    .navbar {

        padding: 15px;

        flex-direction: column;
    }


    .navbar ul {

        margin-top: 10px;

        flex-wrap: wrap;

        justify-content: center;
    }


    .navbar ul li {

        margin: 5px 10px;
    }


    .logo {
        font-size: 26px;
    }

}

</style>

</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<nav class="navbar">

    <div class="logo">
        🍃 Wellness Bite
    </div>


    <ul>

        <li>
            <a href="#">Home</a>
        </li>

        <li>
            <a href="about.php">About Us</a>
        </li>

        <li>
            <a href="#categories">Categories</a>
        </li>

        <li>
            <a href="#foods">Foods</a>
        </li>


        <?php if (isset($_SESSION['customer_id'])): ?>

            <li>
                <a href="#">
                    Hi, <?php echo htmlspecialchars($_SESSION['customer_name']); ?>
                </a>
            </li>

            <li>
                <a href="logout.php">Logout</a>
            </li>

        <?php else: ?>

            <li>
                <a href="register.php">Register</a>
            </li>

            <li>
                <a href="login.php">Login</a>
            </li>

        <?php endif; ?>

    </ul>

</nav>


<!-- =========================
     HERO
========================= -->

<section class="hero">

    <div class="hero-content">

        <h1>
            Healthy Food Delivered Fast
        </h1>

        <p>
            Fresh • Healthy • Nutritious
        </p>


    
       <form action="search.php" method="GET" class="search-box">

    <input
        type="text"
        name="search"
        placeholder="Search Healthy Food"
        required
    >

    <button type="submit">
        Search
    </button>

</form>
    

    </div>

</section>


<!-- =========================
     CATEGORIES
========================= -->

<section class="section" id="categories">

    <h2 class="section-title">
        Food Categories
    </h2>


    <div class="food-categories">

        <a href="salad.php" class="category-box">
            🥗
            <br>
            Salad
        </a>


        <a href="fruits.php" class="category-box">
            🍎
            <br>
            Fruits
        </a>


        <a href="smoothies.php" class="category-box">
            🥤
            <br>
            Smoothies
        </a>


        <a href="diet.php" class="category-box">
            🥑
            <br>
            Diet Meals
        </a>


        <a href="soups.php" class="category-box">
            🍲
            <br>
            Soups
        </a>

    </div>

</section>


<!-- =========================
     SERVICES
========================= -->

<section class="section">

    <h2 class="section-title">
        Our Services
    </h2>


    <div class="services">

        <div class="card">

            <h3>
                🥗 Diet Plans
            </h3>

            <p>
                Personalized healthy diet plans.
            </p>

        </div>


        <div class="card">

            <h3>
                🚚 Fast Delivery
            </h3>

            <p>
                Quick food delivery service.
            </p>

        </div>

    </div>

</section>


<!-- =========================
     POPULAR FOODS
========================= -->

<section class="section" id="foods">

    <h2 class="section-title">
        Popular Foods
    </h2>


    <div class="foods">


        <?php if (mysqli_num_rows($popular) === 0): ?>

            <p style="text-align:center;color:#999;">
                No food items yet — check back soon!
            </p>

        <?php endif; ?>


        <?php while ($p = mysqli_fetch_assoc($popular)): ?>

            <?php

            $img = $p['image']
                ? htmlspecialchars($p['image'])
                : 'veg.jpg';

            ?>


            <div class="food-card">

                <img
                    src="<?php echo $img; ?>"
                    alt="<?php echo htmlspecialchars($p['name']); ?>"
                    onerror="this.src='veg.jpg'"
                >


                <h4>
                    <?php echo htmlspecialchars($p['name']); ?>
                </h4>


                <p>
                    <?php echo htmlspecialchars($p['description']); ?>
                </p>


                <h4>
                    ₹<?php echo number_format($p['price'], 2); ?>
                </h4>


                <a
                    href="payment.php?food_id=<?php echo $p['id']; ?>&item=<?php echo urlencode($p['name']); ?>&price=<?php echo $p['price']; ?>"
                    class="btn"
                >
                    Order Now
                </a>

            </div>


        <?php endwhile; ?>


    </div>

</section>


<!-- =========================
     STATS
========================= -->

<section class="stats">

    <div>

        <h1>
            500+
        </h1>

        <p>
            Orders
        </p>

    </div>


    <div>

        <h1>
            100+
        </h1>

        <p>
            Healthy Foods
        </p>

    </div>


    <div>

        <h1>
            1000+
        </h1>

        <p>
            Customers
        </p>

    </div>

</section>


<!-- =========================
     REVIEWS
========================= -->

<section class="section">

    <h2 class="section-title">
        Customer Reviews
    </h2>


    <div class="reviews">


        <div class="review">

            <h3>
                Priyank
            </h3>

            <p>
                ⭐⭐⭐⭐⭐
            </p>

            <p>
                Best healthy food delivery platform.
            </p>

        </div>


        <div class="review">

            <h3>
                Mayur
            </h3>

            <p>
                ⭐⭐⭐⭐⭐
            </p>

            <p>
                Fresh food and fast delivery.
            </p>

        </div>


        <div class="review">

            <h3>
                Dipu
            </h3>

            <p>
                ⭐⭐⭐⭐⭐
            </p>

            <p>
                Excellent design and healthy meals.
            </p>

        </div>


    </div>

</section>


<!-- =========================
     FOOTER
========================= -->

<div class="footer">

    <h3>
        Wellness Bite
    </h3>

    <p>
        Healthy Food Ordering System
    </p>

    <br>

    <p>
        © 2026 Wellness Bite. All Rights Reserved.
    </p>

</div>


</body>

</html>
