<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us | Wellness Bite</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Arial,sans-serif;
}

body{
background:#f5f5f5;
}

.header{
background:#28a745;
color:white;
padding:60px;
text-align:center;
}

.header h1{
font-size:42px;
}

.header p{
margin-top:15px;
font-size:20px;
}

.container{
width:90%;
max-width:1200px;
margin:40px auto;
}

.box{
background:white;
padding:30px;
margin-bottom:30px;
border-radius:12px;
box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.box h2{
color:#28a745;
margin-bottom:15px;
}

.box p{
font-size:18px;
line-height:30px;
color:#555;
}

.features{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-top:25px;
}

.card{
background:#fff;
padding:25px;
border-radius:10px;
text-align:center;
box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

.card i{
font-size:40px;
color:#28a745;
margin-bottom:15px;
}

.card h3{
margin-bottom:10px;
}

.team{
text-align:center;
}

.team img{
width:130px;
height:130px;
border-radius:50%;
margin-top:20px;
}

.footer{
background:#222;
color:white;
text-align:center;
padding:20px;
margin-top:40px;
}

</style>

</head>

<body>

<div class="header">
<h1>About Wellness Bite</h1>
<p>Healthy Food • Healthy Life</p>
</div>

<div class="container">

<div class="box">
<h2>Who We Are?</h2>

<p>
Wellness Bite is a Healthy Food Ordering Website developed as a BCA Project.
Our goal is to provide fresh, healthy and nutritious food to customers.
We believe that healthy eating should be easy, affordable and delicious.
</p>
</div>

<div class="box">
<h2>Our Mission</h2>

<p>
To inspire people to eat healthy by providing fresh meals, salads,
fruits, smoothies and nutritious foods with quick online ordering.
</p>

</div>

<div class="box">
<h2>Why Choose Wellness Bite?</h2>

<div class="features">

<div class="card">
<i class="fa-solid fa-leaf"></i>
<h3>Healthy Food</h3>
<p>Fresh and nutritious meals.</p>
</div>

<div class="card">
<i class="fa-solid fa-bowl-food"></i>
<h3>Many Categories</h3>
<p>Salads, Smoothies, Fruits & Meals.</p>
</div>

<div class="card">
<i class="fa-solid fa-truck-fast"></i>
<h3>Fast Delivery</h3>
<p>Quick and reliable food delivery.</p>
</div>

<div class="card">
<i class="fa-solid fa-lock"></i>
<h3>Secure System</h3>
<p>Safe Login and Ordering.</p>
</div>

</div>

</div>

<div class="box">
<h2>Our Services</h2>

<p>

✔ Healthy Food Ordering<br><br>

✔ User Registration & Login<br><br>

✔ Online Food Search<br><br>

✔ Easy Food Ordering<br><br>

✔ Secure Customer Information

</p>

</div>

<div class="box team">

<h2>Project Information</h2>

<h3>Project Name</h3>
<p>Wellness Bite</p>

<h3>Developed By</h3>
<p>Dipali Pingal</p>
<p>Mayur Nanjar</p>

<h3>Course</h3>
<p>Bachelor of Computer Applications (BCA)</p>

</div>

<div class="box">

<h2>Contact Us</h2>

<p>

📧 wellnessbite@gmail.com

<br><br>

📞 +91 9106143654

<br><br>

📍 Jamnagar, Gujarat, India

</p>

</div>

</div>

<div class="footer">

© 2026 Wellness Bite | Eat Healthy, Live Healthy

</div>

</body>
</html>