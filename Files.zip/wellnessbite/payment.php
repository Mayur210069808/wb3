<?php
session_start();
require_once 'conn.php';

$item = "Food";
$price = 0;
$foodId = null;
$quantity = 1;
$error = "";

/* GET FOOD DETAILS */
if (isset($_GET['food_id']) && $_GET['food_id'] !== '') {
    $foodId = (int) $_GET['food_id'];
} elseif (isset($_POST['food_id']) && $_POST['food_id'] !== '') {
    $foodId = (int) $_POST['food_id'];
}

if ($foodId !== null && $foodId > 0) {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id, name, price FROM foods WHERE id = ? LIMIT 1"
    );

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $foodId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($food = mysqli_fetch_assoc($result)) {
            $item = $food['name'];
            $price = (float) $food['price'];
        } else {
            $error = "Selected food was not found.";
        }

        mysqli_stmt_close($stmt);
    }
} else {
    $item = $_GET['item'] ?? $_POST['item'] ?? "Food";
    $price = (float) ($_GET['price'] ?? $_POST['price'] ?? 0);
}

/* PLACE ORDER */
if (isset($_POST['place_order'])) {

    $name = trim($_POST['name'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $paymentMethod = trim($_POST['payment'] ?? '');

    $postQuantity = filter_var(
        $_POST['quantity'] ?? 1,
        FILTER_VALIDATE_INT
    );

    if ($postQuantity === false ||
        $postQuantity < 1 ||
        $postQuantity > 20) {
        $postQuantity = 1;
        $error = "Quantity must be between 1 and 20.";
    }

    // Calculate total on the server
    $totalPrice = round($price * $postQuantity, 2);

    if ($name === "" || $mobile === "" ||
        $address === "" || $paymentMethod === "") {
        $error = "Please fill in all delivery details.";
    }

    if ($price < 0) {
        $error = "Invalid food price.";
    }

    if ($error === "") {

        $customerId = $_SESSION['customer_id'] ?? null;
        $postFoodId = $foodId;

        /*
         * Your current orders table does not have
         * a quantity column. The total is saved in price.
         */
        $sql = "INSERT INTO orders
        (
            customer_id,
            customer_name,
            mobile,
            address,
            food_id,
            food_name,
            price,
            payment_method,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("Order Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $stmt,
            "isssisds",
            $customerId,
            $name,
            $mobile,
            $address,
            $postFoodId,
            $item,
            $totalPrice,
            $paymentMethod
        );

        if (!mysqli_stmt_execute($stmt)) {
            die("Order Insert Error: " . mysqli_stmt_error($stmt));
        }

        $orderId = mysqli_insert_id($conn);
        mysqli_stmt_close($stmt);

        // Save payment details
        // UPI is marked Paid here only to match the
        // existing project logic; this does not verify
        // an actual UPI transaction.
        $paymentStatus = (
            stripos($paymentMethod, 'upi') !== false
        ) ? "Paid" : "Pending";

        $pStmt = mysqli_prepare(
            $conn,
            "INSERT INTO payments
             (order_id, amount, method, status)
             VALUES (?, ?, ?, ?)"
        );

        if (!$pStmt) {
            die("Payment Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $pStmt,
            "idss",
            $orderId,
            $totalPrice,
            $paymentMethod,
            $paymentStatus
        );

        if (!mysqli_stmt_execute($pStmt)) {
            die("Payment Insert Error: " . mysqli_stmt_error($pStmt));
        }

        mysqli_stmt_close($pStmt);

        header("Location: order.php?order_id=" . $orderId);
        exit();
    }

    $quantity = $postQuantity;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Wellness Bite</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 450px;
            max-width: 100%;
            margin: 20px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
        }

        h2 {
            text-align: center;
            color: green;
            margin-bottom: 20px;
        }

        .order-box {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            text-align: center;
        }

        .order-box h3 {
            margin: 5px 0 10px;
            color: #333;
            font-size: 22px;
        }

        .price {
            color: green;
            font-weight: bold;
            font-size: 20px;
        }

        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        .quantity-box {
            margin-top: 15px;
        }

        .quantity-box label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .quantity-box input {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }

        .total-box {
            background: #eaf7ea;
            padding: 15px;
            margin: 15px 0;
            border-radius: 6px;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            color: green;
        }

        .total-box small {
            display: block;
            margin-top: 7px;
            font-size: 13px;
            color: #555;
            font-weight: normal;
        }

        button {
            width: 100%;
            padding: 13px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background: darkgreen;
        }

        .error {
            color: #b00020;
            background: #ffe5e5;
            padding: 10px;
            text-align: center;
            border-radius: 5px;
            margin-bottom: 12px;
        }
    </style>
</head>

<body>

<div class="container">

    <h2>Payment Details</h2>

    <div class="order-box">
        <h3><?= htmlspecialchars($item) ?></h3>

        <p>
            Price per item:
            <span class="price">
                ₹<?= number_format($price, 2) ?>
            </span>
        </p>
    </div>

    <?php if ($error !== ""): ?>
        <div class="error">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" id="paymentForm">

        <input type="hidden" name="item"
               value="<?= htmlspecialchars($item, ENT_QUOTES) ?>">

        <input type="hidden" name="price"
               value="<?= htmlspecialchars((string)$price, ENT_QUOTES) ?>">

        <input type="hidden" name="food_id"
               value="<?= htmlspecialchars((string)($foodId ?? ''), ENT_QUOTES) ?>">

        <!-- QUANTITY -->
        <div class="quantity-box">
            <label for="quantity">Quantity</label>

            <input
                type="number"
                id="quantity"
                name="quantity"
                value="<?= (int)$quantity ?>"
                min="1"
                max="20"
                required
            >
        </div>

        <!-- LIVE TOTAL -->
        <div class="total-box">
            Total Amount:
            <div id="totalPrice">
                ₹<?= number_format($price * $quantity, 2) ?>
            </div>
            <small>
                Total updates automatically when quantity changes.
            </small>
        </div>

        <!-- CUSTOMER NAME -->
        <input
            type="text"
            name="name"
            placeholder="Full Name"
            value="<?= htmlspecialchars($_SESSION['customer_name'] ?? '', ENT_QUOTES) ?>"
            required
        >

        <!-- MOBILE -->
        <input
            type="tel"
            name="mobile"
            placeholder="Mobile Number"
            value="<?= htmlspecialchars($_SESSION['customer_mobile'] ?? '', ENT_QUOTES) ?>"
            required
        >

        <!-- ADDRESS -->
        <textarea
            name="address"
            placeholder="Delivery Address"
            required
        ></textarea>

        <!-- PAYMENT METHOD -->
        <select name="payment" required>
            <option value="">Select Payment Method</option>
            <option value="Cash on Delivery">Cash on Delivery</option>
            <option value="UPI">UPI</option>
        </select>

        <button type="submit" name="place_order">
            Place Order
        </button>

    </form>

</div>

<script>
    const quantityInput = document.getElementById('quantity');
    const totalPriceElement = document.getElementById('totalPrice');

    // Unit price comes from the PHP-rendered food price.
    const unitPrice = <?= json_encode($price) ?>;

    function updateTotal() {
        let quantity = parseInt(quantityInput.value, 10);

        if (!Number.isFinite(quantity) || quantity < 1) {
            totalPriceElement.textContent = '₹' +
                (unitPrice * 1).toFixed(2);
            return;
        }

        if (quantity > 20) {
            quantity = 20;
            quantityInput.value = 20;
        }

        const total = unitPrice * quantity;

        totalPriceElement.textContent =
            '₹' + total.toFixed(2);
    }

    quantityInput.addEventListener('input', updateTotal);
    quantityInput.addEventListener('change', updateTotal);

    updateTotal();
</script>

</body>
</html>

