<?php
session_start();
require_once 'conn.php';

$message = "";
$msgType = "success";

if (isset($_POST['register'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $password = $_POST['password'];

    $check = mysqli_prepare($conn, "SELECT id FROM customers WHERE email = ?");
    mysqli_stmt_bind_param($check, "s", $email);
    mysqli_stmt_execute($check);
    $exists = mysqli_stmt_get_result($check);

    if (mysqli_num_rows($exists) > 0) {
        $message = "An account with this email already exists.";
        $msgType = "error";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "INSERT INTO customers (name, email, mobile, password) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $mobile, $hashed);

        if (mysqli_stmt_execute($stmt)) {
            $message = "Registration Successful! You can now log in.";
        } else {
            $message = "Something went wrong. Please try again.";
            $msgType = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Wellness Bite</title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial,sans-serif;
        }

        body{
            background:white;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
        }

        .container{
            width:400px;
            background:white;
            padding:30px;
            border-radius:15px;
            box-shadow:0 5px 15px rgba(0,0,0,0.3);
            animation:zoom 0.8s;
        }

        @keyframes zoom{
            from{
                transform:scale(0.7);
                opacity:0;
            }
            to{
                transform:scale(1);
                opacity:1;
            }
        }

        h2{
            text-align:center;
            color:#28a745;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:12px;
            margin:10px 0;
            border:1px solid #ccc;
            border-radius:8px;
            font-size:16px;
        }

        input[type=submit]{
            background:#28a745;
            color:white;
            border:none;
            cursor:pointer;
            font-size:18px;
        }

        input[type=submit]:hover{
            background:#218838;
        }

        .msg{
            text-align:center;
            margin-bottom:15px;
            font-weight:bold;
        }

        .msg.success{ color:green; }
        .msg.error{ color:red; }

        p{
            text-align:center;
            margin-top:15px;
        }

        a{
            color:#28a745;
            text-decoration:none;
        }
    </style>

</head>
<body>

<div class="container">

<h2>Create Account</h2>

<?php if ($message != ""): ?>
    <div class="msg <?php echo $msgType; ?>"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<form method="post">

<input type="text" name="name" placeholder="Full Name" required>

<input type="email" name="email" placeholder="Email Address" required>

<input type="text" name="mobile" placeholder="Mobile Number" required>

<input type="password" name="password" placeholder="Password" required minlength="4">

<input type="submit" name="register" value="Register">

</form>

<p>Already have an account?
<a href="login.php">Login</a></p>

</div>

</body>
</html>
