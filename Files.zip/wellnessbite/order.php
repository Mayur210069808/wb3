
<?php
require_once 'conn.php';

$orderId = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
$order = null;

if ($orderId > 0) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM orders WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $orderId);
    mysqli_stmt_execute($stmt);
    $order = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$item = $order['food_name'] ?? (isset($_GET['item']) ? $_GET['item'] : "Food");
?>

<!DOCTYPE html>
<html>
<head>
<title>Order Successful</title>

<style>
body{
    margin:0;
    padding:0;
    font-family:Arial,sans-serif;
    background:linear-gradient(to right,#56ab2f,#a8e063);
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.box{
    background:white;
    width:450px;
    padding:40px;
    border-radius:15px;
    text-align:center;
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
    animation:zoom 0.6s;
}

@keyframes zoom{
    from{
        transform:scale(0.7);
        opacity:0;
    }
    to{
        transform:scale(1);
        opacity:1;
    }
}

h1{
    color:green;
}

h2{
    color:#333;
}

p{
    color:#666;
}

.order-id{
    display:inline-block;
    background:#eef8ee;
    color:#218838;
    padding:6px 14px;
    border-radius:20px;
    font-weight:bold;
    margin-top:10px;
}

a{
    display:inline-block;
    margin-top:20px;
    padding:12px 25px;
    background:green;
    color:white;
    text-decoration:none;
    border-radius:8px;
}

a:hover{
    background:darkgreen;
}
</style>

</head>
<body>

<div class="box">

<h1>🎉 Order Placed Successfully!</h1>

<h2><?php echo htmlspecialchars($item); ?></h2>

<?php if ($order): ?>
    <p class="order-id">Order #<?php echo $order['id']; ?></p>
    <p>Status: <b><?php echo htmlspecialchars($order['status']); ?></b></p>
<?php endif; ?>

<p>Thank you for ordering from <b>Wellness Bite</b>.</p>

<a href="index.php">Back To Home</a>

</div>

</body>
</html>
